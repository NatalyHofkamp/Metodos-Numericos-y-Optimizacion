import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation

# características del sistema
m = 1.0
l = 1.0
g = 9.8

def F1(u1,u2):
    w1= u1[1] #omega
    w2=u2[1]
    theta1= u1[0] #theta
    theta2 = u2[0]
    dif =theta1-theta2
    return np.array([u1[1], 
                    ((-g/l)*(2*np.sin(theta1)-np.cos(dif)*np.sin(theta2))+np.sin(dif)*(w2 + np.cos(dif)*w1))/(2-(np.cos(dif))**2)])
def F2(u1,u2):
    w1= u1[1]
    w2=u2[1]
    theta1= u1[0]
    theta2 = u2[0]
    dif =theta1-theta2
    return np.array([u2[1], 
                    ((-g/l)*(np.sin(theta2)- 2*np.cos(dif)*np.sin(theta1)) +np.sin(dif)*(w1+ np.cos(dif)*w2))/(2-(np.cos(dif)**2))])

def rk4_method(u1,u2,h,F,case):
    k1 = F(u1,u2)
    k2 = F(u1,u2 + 0.5*h*k1)
    k3 = F(u1,u2 + 0.5*h*k2)
    k4 = F(u1,u2 + h*k3)
    return case+ h*(k1 + 2*k2 + 2*k3 + k4)/6 

def plot(num,x,y,x_title,y_title,filename,label,style):
    plt.figure(num)
    plt.plot(x, y, label = label, linestyle= style )
    plt.xlabel(x_title)
    plt.ylabel(y_title)
    plt.legend ()
    plt.savefig(filename)

def trayectory(u,h):
    #TRAYECTORIA EN FUNCIÓN DEL TIEMPO
    r1=(l * np.sin(u[0][1]),-l * np.cos(u[0][1]))
    r2= (l * np.sin(u[0][1]) +l * np.sin(u[1][1]),
        -l * np.cos(u[0][1])-l * np.cos(u[1][1]))
    plot(4,r1[0],r1[1],'Posición x(m)','Posición y(m)',("tr_"+u[2]+"_"+str(h))+".png",'trayectoria del pendulo superior ',"solid")    
    plot(5,r2[0],r2[1],'Posición x(m)','Posición y(m)',(u[2]+"_"+str(h))+".png",'trayectoria del pendulo inferior ',"solid")

def graphs(time,pendulum,h):
    filename_ang= "ang(t)"+pendulum[2]+str(h)
    filename_ang= "ang(t)"+pendulum[2]+str(h)+".png"
    #angulo en función del tiempo
    theta0_1 = np.full(len(time),  pendulum[0][1][0]) 
    theta0_2 = np.full(len(time),  pendulum[1][1][0]) 
    thetasol1 = pendulum[0][1][:len(time)]
    thetasol2 = pendulum[1][1][:len(time)]
    plot(1,time, thetasol1,'Tiempo (s)', r'$\theta_1$ (rad)',
            filename_ang, r'$\theta_1$',"--")                    
    plot(1,time, thetasol2,'Tiempo (s)', r'$\theta_2$ (rad)',
            filename_ang, r'$\theta_2$',':')  
    plot(1,time, theta0_1,'Tiempo (s)', r'$\theta_1$ (rad)',
            filename_ang, r'$\theta_1$ inicial',"solid")                    
    plot(1,time, theta0_2,'Tiempo (s)', r'$\theta_2$ (rad)',
            filename_ang, r'$\theta_2$ inicial','solid')  

def anim(pendulum,time,sample,t,h):
    def animate(i):
        theta1 = pendulum[0][1][i]
        theta2 = pendulum[1][1][i]
        x1 = l * np.sin(theta1)
        y1 = -l * np.cos(theta1)
        x2 = x1 + (l * np.sin(theta2))
        y2 = y1 + (-l * np.cos(theta2))
        plt.title("Tiempo : "+str(time[i])+" \n Ángulo primer péndulo:"+str(theta1) + "\n Ángulo segundo péndulo:"+str(theta2))
        ln1.set_data([0, x1, x2], [0, y1, y2])
    fig, ax = plt.subplots(1,1, figsize=(8,8))
    ln1, = plt.plot([], [], 'ro--', lw=3, markersize=8)
    ax.set_ylim(-2.2,2.2)
    ax.set_xlim(-0.1,0.1)
    ax.grid()
    ani = animation.FuncAnimation(fig, animate, np.arange ( start=0, stop= sample, step= 100))
    ani.save(pendulum[2]+"_"+str(h)+'.gif',writer='pillow',fps=10)

def generate_pendulum(theta,omega):
    u = np.array([np.radians(theta), omega])
    thetasol=[u[0]]
    omegasol= [u[1]]
    return [u,thetasol,omegasol]

def main ():

    omega0=0
    #condiciones iniciales
    values= [0.5,0.5,38,1] #angulos iniciales
    t=10
    samples=[100,1000,10000]

    for sample in samples:
        h = t/sample # paso
        time = np.linspace(0, t, sample) # intervalo de tiempo
        u1 = generate_pendulum(values[0],omega0) #theta - omega
        u2 = generate_pendulum(values[1],omega0)
        u3 = generate_pendulum(values[2],omega0) #theta - omega
        u4 = generate_pendulum(values[3],omega0)

        pendulums= [[u1,u2,"dob_1"],
                    [u3,u4,"dob_2"]]
        for pendulum in pendulums:
            for x in time:
                pendulum[0][0] = rk4_method(pendulum[0][0],pendulum[1][0],h,F1,pendulum[0][0])
                pendulum[0][1].append(pendulum[0][0][0]) #thetasol1
                pendulum[0][2].append(pendulum[0][0][1]) #Omegasol1
                pendulum[1][0] = rk4_method(pendulum[0][0],pendulum[1][0],h,F2,pendulum[1][0])          
                pendulum[1][1].append(pendulum[1][0][0]) #thetasol2
                pendulum[1][2].append(pendulum[1][0][1]) #Omegasol2

            # trayectory(pendulum,h)
            # graphs(time,pendulum,h)
            anim(pendulum,time,sample,t,h)
            plt.show()

if __name__=='__main__':
    main()