import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from scipy.linalg import expm

# características del sistema
m = 1.0
l = 1.0
g = 9.8

def F(u):
    return np.array([u[1],-g*np.sin(u[0])/l])

def exp_euler(u,h):
    # metodo de euler explícito
    return u[0] + h*F(u[0]) 


def semi_imp_euler(u,h):
    #método de euler semi-implícito
    u[0][1]= u[0][1]-h*(g*np.sin(u[0][0])/l) #omega
    u[0][0]=u[0][0]+h*u[0][1] #theta
    return u

def linear_method (u,t):
    #resolucion analítica 
    a=u[0][1] #omega
    b=u[0][0] #theta
    u[1]= np.array((a*np.sin(((g/l)**(1/2))*t))+ (b*np.cos(((g/l)**(1/2))*t)))#thetasol
    u[2]= np.array((a*np.cos(((g/l)**(1/2))*t)*((g/l)**(1/2)))-(b*np.sin(((g/l)**(1/2))*t)*((g/l)**(1/2)))) #omegasol
    return u

def rk4_method(u,h):
    #metodo runge-kutta de orden 4
    k1 = F(u[0])
    k2 = F(u[0] + 0.5*h*k1)
    k3 = F(u[0]+ 0.5*h*k2)
    k4 = F(u[0] + h*k3)
    return u[0] + h*(k1 + 2*k2 + 2*k3 + k4)/6



def plot(num,x,y,x_title,y_title,filename,label,style):
    plt.figure(num)
    plt.plot(x, y, label = label, linestyle= style )
    plt.xlabel(x_title)
    plt.ylabel(y_title)
    plt.legend ()
    plt.savefig(filename)

def graphs(time,pendulums,h,theta0,omega0):
    for pend in pendulums:
        filename_ang= "ang(t)"+str(theta0)+"_"+str(h)+".png"
        filename_vel_ang= "vel_ang(t)"+str(theta0)+"_"+str(h)+".png"
        #angulo en función del tiempo
        plot(1,time, pend[1][:len(time)],'Tiempo (s)', 'Ángulo (rad)',
            filename_ang,pend[3],pend[4])
        #velocidad en función del tiempo
        plot(2,time, pend[2][:len(time)],'Tiempo (s)','Velocidad angular (rad/s)',
             filename_vel_ang,pend[3],pend[4])
                
  
   
def trayectory(u,h,theta0):
    # TRAYECTORIA EN FUNCIÓN DEL TIEMPO
    for pend in u:
        filename= "tr_"+str(theta0)+"_"+str(h)+".png"
        plot(4,(l * np.sin(pend[1])),(-l * np.cos(pend[1])),'Posición x(m)',
                'Posición y(m)',filename,pend[3],pend[4])


def energy(u,time,h,theta0):
 # calcular energía cinética y potencial
    energia_cinetica = 0.5 * m * (l* np.array(u[2]))**2 #omega
    energia_potencial = m * g * l * (1 - np.cos(u[1])) #theta
    energia_potencial.resize(len(time))
    energia_cinetica.resize(len(time))
    energia_total = energia_cinetica + energia_potencial

    fig9, ax = plt.subplots(1,1, figsize=(8,8))
    plt.plot(time, energia_total, label = 'energía total')
    plt.plot(time, energia_cinetica, label = 'energía cinética', linestyle= '--')
    plt.plot(time, energia_potencial, label = 'energía potencial', linestyle = '-.')
    plt.xlabel('Tiempo')
    plt.ylabel('Energía ')
    plt.plot()
    plt.legend()
    plt.savefig("en_"+u[5]+"_"+str(theta0)+"_"+str(h)+".png")
    

def anim(u,time,samples,t,theta0,h):
    def animate(i):
        theta = u[1][i]
        x1 = l * np.sin(theta)
        y1 = -l * np.cos(theta)
        plt.title("Pendulo simple generado con "+ str(u[3])+"\ntiempo: "+str(time[i])+"\n Ángulo: "+str(theta)+
                "\nÁngulo inicial:"+ str(theta0)+"     Paso temporal:"+str(h))
        ln1.set_data([0, x1], [0, y1])
    fig, ax = plt.subplots(1,1, figsize=(8,8))
    ln1, = plt.plot([], [], 'ro--', lw=3, markersize=8)
    ax.set_ylim(-2,2)
    ax.set_xlim(-2,2)
    ax.grid()
    ani = animation.FuncAnimation(fig, animate, np.arange ( start=0, stop= samples, step= 100))
    ani.save(u[5]+"_"+str(h)+'.gif',writer='pillow',fps=10)

def generate_pendulum(theta,omega):
    u = np.array([np.radians(theta), omega])
    thetasol=[u[0]]
    omegasol= [u[1]]
    return [u,thetasol,omegasol]

def main ():
    #condiciones iniciales
    omega0 = 0 #velocidad angular inicial
    t=5
    thetas= [5,10,60] # angulo inicial en grados
    samples=[100,1000,10000] 
   

    for theta0 in thetas:
        for sample in samples:
            h = t/sample # paso temporal
            time = np.linspace(0, t, sample) # intervalo de tiempo

            u1= generate_pendulum(theta0,omega0) #pendulo con euler explícito
            u2 = generate_pendulum(theta0,omega0) #pendulo para runge kutta
            u3 = generate_pendulum(theta0,omega0) #pendulo para euler semi implícito
            u_real = generate_pendulum(theta0,omega0)

            for t in time:
                u1[0]= exp_euler(u1,h)
                u1[1].append(u1[0][0])
                u1[2].append(u1[0][1])
                u2[0] = rk4_method(u2,h)
                u2[1].append(u2[0][0])
                u2[2].append(u2[0][1])
                u3 = semi_imp_euler(u3,h)
                u3[1].append(u3[0][0])
                u3[2].append(u3[0][1])
    
            u1.append("Euler explícito")
            u1.append('-.')
            u1.append("eu_exp")
            u2.append("Runge Kutta de orden 4")
            u2.append('--')
            u2.append("rk4_simple")
            u3.append("Euler semi implícito")
            u3.append(':')
            u3.append("eu_semi_imp")

            u_real = linear_method(u_real,time) #lista con thetas y omegas
            u_real.append("Solución analítica")
            u_real.append('solid')
            u_real.append("sol_anali")

            u123 = [u_real,u1,u2,u3]
            trayectory(u123,h,theta0)
            graphs(time,u123,h,theta0,omega0)
            for u in u123:
               energy(u,time,h,theta0)
               anim(u,time,sample,t,theta0,h)
            plt.show()

if __name__=='__main__':
    main()