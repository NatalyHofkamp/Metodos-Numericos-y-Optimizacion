from PIL import Image
from pylab import *


def plot(image, description, filename,color,title):
    plt.figure()
    plt.imshow(image,cmap ='gray')
    plt.text(21,26,description,fontsize = 12, ha ="center",va ='center',color =color)
    x= np.linspace(0,1,100)
    y = np.linspace(0,1,100)
    X,Y =np.meshgrid(x,y)
    Z =X**2 + Y**2
    contorno = plt.contourf(X,Y,Z,cmap='gray')
    plt.colorbar(contorno)
    plt.axis('off')
    plt.title(title, fontsize=20, fontweight= 3)
    plt.savefig(filename)



def plot_image(image,filename,title,color):
    plt.figure()
    image = Image.open(image)
    plt.imshow(image,cmap ='gray')
    plt.axis('off')
    plt.savefig(filename)


def image_to_vector(image):
    image_array = np.array(image)
    image_vector = image_array.flatten()
    return image_vector


def get_svd(mat):
    U, S, VT = np.linalg.svd(mat)
    return VT

def compile_images(image_paths):
    image_matrices = []
    for image_path in image_paths:
        image = Image.open(image_path)
        image_matrix = image_to_vector(image)
        image_matrices.append(image_matrix)
    return np.vstack(image_matrices)

def create_image_paths():
    image_paths=[]
    for i in range (16):
        filename ="img_ori/img"+str(i)+".jpeg" # ->para terminal
        image_paths.append(filename)
    return image_paths

def visualize_eigenvalues(VT):
    first_dim = VT[0, :]  # Columna
    dim_16 = VT[15, :]
    dim_17 = VT[16, :]
    last_dim = VT[-1, :]

    first_dim_image = np.reshape(first_dim, (28, 28))
    last_dim_image = np.reshape(last_dim, (28, 28))
    dim_16 = np.reshape(dim_16, (28, 28))
    dim_17 = np.reshape(dim_17, (28, 28))

    # Establecer los límites de la escala de color para todas las imágenes
    plot(first_dim_image, 'Primer autovector', 'results/first_av.jpg','black','A')
    plot(dim_16, 'Autovector 15', 'results/dim_14.jpg','black','B')
    plot(dim_17, 'Autovector 16', 'results/dim_15.jpg','white','C')



def main():
    img_paths = create_image_paths()
    matrix = compile_images(img_paths)
    VT = get_svd(matrix)
    print(VT.shape)
    visualize_eigenvalues(VT)
    plot_image(img_paths[9],'results/imagen'+str(9)+'.jpg','imagen '+str(9),'white')
    plot_image(img_paths[1],'results/imagen'+str(1)+'.jpg','imagen '+str(1),'white')
    plot_image(img_paths[6],'results/imagen'+str(6)+'.jpg','imagen '+str(6),'white')
    plot_image(img_paths[5],'results/imagen'+str(5)+'.jpg','imagen '+str(5),'white')
    

if __name__ == '__main__':
    main()