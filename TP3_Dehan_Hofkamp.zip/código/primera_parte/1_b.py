from pylab import *
from PIL import Image


def compress_image(image, d):
    U, s, Vt = np.linalg.svd(image)
    return U[:, :d] @ np.diag(s[:d]) @ Vt[:d, :]

def find_min_dim(image, error_threshold):
    d = 1
    error = 1.0
    while error > error_threshold and d <= min(image.shape):
        error = calculate_error(image,d)
        d += 1
    return d-1

def calculate_error(image, d):
    compressed_image = compress_image(image, d)
    return np.linalg.norm(image - compressed_image, ord='fro') / np.linalg.norm(image, ord='fro')

def iterate_images(file_paths, d):
    print("Número mínimo de dimensiones (d):", d)
    errors = []
    for file_path in file_paths:
        image = np.array(Image.open(file_path))
        errors.append(calculate_error(image, d))
    return errors

def create_image_paths():
    image_paths=[]
    for i in range (16):
        filename ="img_ori/img"+str(i)+".jpeg" 
        image_paths.append(filename)
    return image_paths

def plot(image, description, filename,color,title):
    plt.figure()
    plt.imshow(image,cmap ='gray')
    plt.text(21,26,description,fontsize = 12, ha ="center",va ='center',color =color)
    plt.axis('off')
    plt.title(title, fontsize=20, fontweight= 3)
    plt.savefig('results/'+filename)


def scatter_plot_errors(errors):
    x = np.arange(1,len(errors)+1)
    y = errors
    plt.bar(x, errors, color='violet', label='Similitud al centroide 1')
    plt.xlabel('Imagen')
    plt.ylabel('Error de compresión')
    plt.xticks(x)    
    plt.savefig('results/scatter_error.jpg')
    plt.show()

def show_images(image,d):
    plot(image, 'original','original.jpg','white','D')
    comp_img_final = compress_image(image, d)
    comp_img_inter = compress_image(image, 5)
    comp_img_worst = compress_image(image, 2)
    plot(comp_img_inter, '5 autovalores','img_'+str(5)+'_dim.jpg','white','B')
    plot(comp_img_worst,'2 autovalores','img_'+str(2)+'_dim.jpg','white','A')
    plot(comp_img_final, str(d)+' autovalores','img_'+str(d)+'_dim.jpg','white','C')

def calc_all_errors(image):
    error = 1.0
    errors = []
    dimen = []
    d=1;
    while d < min(image.shape):
        error = calculate_error(image,d)
        d += 1
        errors.append(error)
        dimen.append(d)
    return dimen,errors

def plot_compression_error(image, min_dim):
    dimen, errors = calc_all_errors(image)
    plt.plot(dimen, errors)
    plt.xlabel('Cantidad de Autovalores')
    plt.ylabel('Error de Compresión')
    plt.axhline(y=0.05, color='purple', linestyle='--', label='Error 0.05')
    plt.grid(True)
    plt.scatter(min_dim, errors[min_dim-2], marker='x', color='red', label='Dimensión Mínima')
    plt.legend()
    plt.savefig('results/compression_error.png')
    plt.show()

def main():
    image_paths = create_image_paths()
    error_threshold = 0.05
    first_image = np.array(Image.open(image_paths[0]))
    min_dim= find_min_dim(first_image, error_threshold)
    plot_compression_error (first_image,min_dim)
    errors_images = iterate_images(image_paths, min_dim)
    scatter_plot_errors(errors_images)
    show_images(first_image,min_dim);

    

if __name__ == '__main__':
    main()