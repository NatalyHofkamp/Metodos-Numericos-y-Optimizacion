import pandas as pd
from pylab import *
from brokenaxes import brokenaxes
from scipy.spatial.distance import pdist

def get_VT(mat):
    U, S, VT = np.linalg.svd(mat)
    return S,VT

def proyeccion(matriz,VT,d):
    coordenadas_svd = []
    for i in range(matriz.shape[0]):
        coordenadas_svd.append(VT[:d[0], :] @ matriz[i, :])
    coordenadas_svd = np.array(coordenadas_svd)
    return coordenadas_svd 

def get_avg_desv(matriz):
    return np.std(matriz)

def histograms (datos,d):
    distancias = pdist(datos)
    plt.hist(distancias, bins='auto')
    plt.xlabel('Distancia')
    plt.ylabel('Frecuencia')
    plt.title(d[1], fontsize = 20, fontweight= 3)
    plt.savefig('results/histogram_'+d[1]+'.jpg')
    plt.show()

def get_centroids(datos, k):
    centroids = datos[np.random.choice(len(datos), 2, replace=False)]
    i = 0
    while True:
        i += 1
        asignaciones = np.argmin(np.linalg.norm(datos[:, np.newaxis] - centroids, axis=-1), axis=-1)
        nuevos_centroids = np.array([datos[asignaciones == j].mean(axis=0) for j in range(k)]) 
        if np.all(centroids == nuevos_centroids):
            break
        centroids = nuevos_centroids
    return centroids

def clusters(datos, centroids,avg_desv):
    cluster1 = []
    cluster2 = []
    for i in datos:
        cal1 = np.exp(-((np.linalg.norm(i - centroids[0]))**2) / (2 * (avg_desv**2)))
        cal2 = np.exp(-((np.linalg.norm(i - centroids[1]))**2) / (2 * (avg_desv**2)))
        if cal1 > cal2:
            cluster1.append((i))
        else:
            cluster2.append((i))
    return cluster1, cluster2

def graph_cords(cord1,cord2,centroids):
    x_cord1,y_cord1= zip(*cord1)
    x_cord2,y_cord2= zip(*cord2)
    plt.xlabel('x')
    plt.ylabel('y')
    plt.scatter(x_cord1,y_cord1, color='pink', label='Cluster 1')
    plt.scatter(x_cord2,y_cord2, color='lightblue', label='Cluster 2')
    plt.scatter(centroids[0, 0],centroids[0, 1], marker='x', color='red', label='Centroide 1')
    plt.scatter(centroids[1, 0], centroids[1, 1], marker='x', color='blue', label='Centroide 2')
    plt.legend()
    plt.savefig('clusters.jpg')
    plt.show()

def compress_matrix(mat, d):
    U, s, Vt = np.linalg.svd(mat)
    return U[:, :d] @ np.diag(s[:d]) @ Vt[:d, :]

    
def print_clusters(cluster1,cluster2,centroids):
    return graph_cords(cluster1,cluster2,centroids)


def graph_s(S):
    S = np.array(S)
    S = S / np.max(S)
    fig = plt.figure()
    bax = brokenaxes(ylims=[(0, 0.05),(0.6,1)])
    bax.plot(range(24), S[:24])
    bax.scatter(2, S[2], marker='o', color='red',label="Autovalor 2")
    bax.scatter(4, S[4], marker='o', color='purple',label="Autovalor 4")
    bax.scatter(20, S[20], marker='o', color='green',label="Autovalor 20")
    bax.set_xlabel('Autovalor')
    bax.set_ylabel('Valor del autovalor (normalizado)')
    bax.legend()
    bax.grid(True)
    plt.savefig('results/dim_info.jpg')
    plt.show()

def main ():
    filename = "dataset_clusters.csv"  
    dataframe = pd.read_csv(filename)
    mat = dataframe.values
    avg_desv = get_avg_desv(mat)
    k = 2
    S,VT = get_VT(mat)
    graph_s(S)
    for d in [(2,'A'),(4,'B'),(20,'C')]:
        proy_mat = proyeccion(mat,VT,d)
        centroids = get_centroids(proy_mat, k)
        histograms(proy_mat,d)
        cluster1,cluster2 = clusters(proy_mat, centroids,avg_desv)
        # print_clusters(cluster1,cluster2,centroids)

if __name__ == '__main__':
    main()
