import numpy as np
import matplotlib.pyplot as plt

# Datos de ejemplo
iteraciones = np.arange(1, 11)
error_practico = np.array([0.8, 0.4, 0.2, 0.1, 0.05, 0.02, 0.01, 0.005, 0.002, 0.001])
error_teorico = np.array([0.6, 0.5, 0.4, 0.3, 0.25, 0.2, 0.18, 0.16, 0.14, 0.12])

# Graficar los errores práctico y teórico
plt.plot(iteraciones, error_practico, label='Error práctico')
plt.plot(iteraciones, error_teorico, label='Error teórico')

# Configuración del gráfico
plt.xlabel('Número de iteraciones')
plt.ylabel('Error')
plt.title('Convergencia del error práctico y teórico')
plt.legend()

# Mostrar el gráfico
plt.show()
