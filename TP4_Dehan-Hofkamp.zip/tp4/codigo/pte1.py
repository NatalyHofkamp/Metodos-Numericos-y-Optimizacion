from pylab import *
m = 5
n = 100
seed(1234)
# Generar matriz A aleatoria
def generate_random_matrix(m, n):
    return np.random.rand(m, n)

# Generar vector b aleatorio
def generate_random_vector(m):
    return np.random.rand(m)

# Obtener el valor máximo propio del Hessiano
def max_eigenvalue(H):
    eigenvalues = np.linalg.eigvals(H)
    max_eigenvalue = np.max(eigenvalues)
    return max_eigenvalue

# Función de costo F(x)
def F(A, b, x, delta = None):
    Ax_minus_b = np.dot(A, x) - b
    return np.dot(Ax_minus_b, Ax_minus_b)

# Función de costo F2(x)
def F2(A, b, x, delta2):
    return F(A, b, x,0) + delta2 * np.linalg.norm(x, ord=2)**2

# Función de costo F1(x)
def F1(A, b, x, delta1):
    return F(A, b, x,0) + delta1 * np.linalg.norm(x, ord=1)

# Gradiente de la función de costo F(x)
def grad_F(A, b, x,delta):
    Ax_minus_b = np.dot(A, x) - b
    return 2 * np.dot(A.T, Ax_minus_b)

def grad_F1(A,b,x,delta1):
    return grad_F(A, b, x,0)+ (delta1 * np.sign(x))

def grad_F2(A, b, x, delta2):
    grad = grad_F(A, b, x, 0)
    return grad + (2 * delta2 * x)

#estaría bueno un vector que vaya guardando las soluciones :)
def gradient_descent(Nsteps, s, A, b, grad_F, F, delta):
    xk = generate_random_vector(n)
    error = np.zeros(Nsteps+1)
    error[0] = np.linalg.norm(np.dot(A, xk) - b)# Calcular el valor de la función de costo para la solución inicial
    for i in range(Nsteps):
        xk = xk - s * grad_F(A, b, xk, delta)
        error[i+1] = np.linalg.norm(np.dot(A, xk) - b)  # Calcular el valor de la función de costo en cada iteración
    return xk, error

def sol_SVD (A,b):
    U, S, Vt = np.linalg.svd(A, full_matrices=False)
    S_matrix = np.zeros((U.shape[0],Vt.shape[0]))
    S_matrix[:S.shape[0], :S.shape[0]] = np.diag(S)
    At = np.dot(np.dot(np.transpose(Vt),np.linalg.pinv(S_matrix)),np.transpose(U))
    return np.dot(At,b)


def generate_solutions(Nsteps,s,A,b,delta_1,delta_2):
    x,sol0= gradient_descent(Nsteps,s, A,b,grad_F,F,0)
    x_1,sol1 = gradient_descent(Nsteps,s, A,b,grad_F1,F1,delta_1)
    x_2,sol2 = gradient_descent(Nsteps,s, A,b,grad_F2,F2,delta_2)
    x_svd = sol_SVD(A,b)
    return [x,x_1,x_2,x_svd],[(sol0,'F'),(sol1,'F1'),(sol2,'F2')]

def print_sol(xs):
    x,x_1,x_2,x_SVD = xs
    plt.figure()
    plt.title('Soluciones con distintas funciones de costo')
    plt.plot(x,label ="solución F",linestyle =':')
    plt.plot(x_1, label = "solución F1")
    plt.plot (x_2, label= "solución F2")
    plt.plot (x_SVD, label ="solución SVD", linestyle='--')
    plt.ylabel('Valor del componente ')
    plt.xlabel('Indice del componente')
    plt.legend()

def print_error(Nsteps, lambda_max, A, b):
    s = 1 / lambda_max  # Paso
    plt.figure()
    deltas = [(0.001, 0.001), (1e-2 * lambda_max, 1e-3 * lambda_max), (4, 4)]
    errors = [[], []]
    for delta1, delta2 in deltas:
        xs, solutions = generate_solutions(Nsteps, s, A, b, delta1, delta2)
        for i in [1, 2]:
            errors[i-1].append(np.linalg.norm(np.dot(A, xs[i]) - b))
    delta_F1 = [delta[0] for delta in deltas]  # Valores de delta para el eje x
    delta_F2 = [delta[1] for delta in deltas]  # Valores de delta para el eje x
    plt.plot(delta_F1, errors[0], color='purple', label='F1')  # Gráfico para F1
    plt.plot(delta_F2, errors[1], color='red', label='F2')  # Gráfico para F2
    plt.scatter(delta_F1, errors[0], color='purple', marker='o')  # Marcador para F1
    plt.scatter(delta_F2, errors[1], color='red', marker='o')  # Marcador para F2
    for i, delta in enumerate(deltas):
        plt.text(delta[0], errors[0][i], '{:.1f}'.format(delta[0]), ha='center', va='bottom')  # Texto para F1 con 3 decimales
        plt.text(delta[1], errors[1][i], '{:.1f}'.format(delta[1]), ha='center', va='bottom')  # Texto para F2 con 3 decimales
    plt.xlabel('Valor de delta')
    plt.ylabel('Error')
    plt.title('Error de la solución según el valor de Delta')
    plt.legend()
    plt.show()

def print_bar_norm(s, A, b, delta1, delta2):
    norms = []
    for Nsteps in [100,1000,2000]:
        plt.figure()
        xs, solutions = generate_solutions(Nsteps, s, A, b, delta1, delta2)
        names = ['F2', 'SVD']
        x_values = np.arange(len(names))  # Valores para el eje x
        bar_width = 0.8  # Ancho de las barras
        for i in [2, 3]:
            norm = np.linalg.norm(xs[i], ord=2)
            norms.append(norm)
            plt.bar(i-2, norm, width=bar_width, label=names[i-2])
        
        plt.ylim(0, 3)  # Establecer los límites del eje y
        plt.xticks(x_values, names)  # Asignar los nombres a las posiciones del eje x
        plt.ylabel('Norma 2')
        plt.title(f'Norma 2 de la solución con {Nsteps} iteraciones')
        plt.show()

def main():
    Nsteps = 1000#pasos
    A = generate_random_matrix(m, n) 
    b = generate_random_vector(m)
    H = 2 * np.dot(A.T, A)
    lambda_max= max_eigenvalue(H) #max autovalor de H
    s = 1/lambda_max #step
    #condiciones* lambda_max
    delta2 = 1e-2 * lambda_max
    delta1 = 1e-3 * lambda_max
    xs,solutions = generate_solutions(Nsteps,s,A,b,delta1,delta2)
    print_sol(xs)
    print_error(Nsteps,lambda_max,A,b)
    print_bar_norm(s,A,b,delta1,delta2)
    

if __name__ == '__main__':
    main()