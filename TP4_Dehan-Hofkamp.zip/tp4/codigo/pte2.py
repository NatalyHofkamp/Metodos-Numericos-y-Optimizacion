from pylab import *
seed(1234)
def generar_matrices_condicion(numero_condicion, m, n):
    # Generar matriz aleatoria A con número de condición dado
    U, _, VT = np.linalg.svd(np.random.randn(m, n))
    singular_values = np.linspace(1, numero_condicion, min(m, n))
    A = U.dot(np.diag(singular_values)).dot(VT)
    
    # Generar vector aleatorio b
    b = np.random.randn(m)
    
    return A, b

def calcular_funcion_costo(A, b, x):
    # Calcular la función de costo F
    Ax_minus_b = np.dot(A, x) - b
    return np.dot(Ax_minus_b, Ax_minus_b)
   

def gradiente_descendente(numero_condicion, m, n, umbral_error):
    A, b = generar_matrices_condicion(numero_condicion, m, n)
    
    # Inicialización de parámetros
    x = np.zeros(n)  # Inicializar en ceros para mejorar convergencia
    alpha = 1 / (2 * np.linalg.norm(A.T.dot(A), ord=2))  # Ajustar el factor de aprendizaje

    # Iteraciones del gradiente descendente
    iteracion = 0
    errores_practicos = []
    errores_teoricos = []
    while True:
        iteracion += 1
        
        # Cálculo del gradiente
        gradiente = A.T.dot(A.dot(x) - b)

        # Actualización de parámetros
        x = x - alpha * gradiente

        # Cálculo del error práctico
        error_practico = calcular_funcion_costo(A, b, x)
        errores_practicos.append(error_practico)

        # Cálculo del error teórico
        m_valor_singular_mas_chico = np.min(np.linalg.svd(A)[1])
        M_valor_singular_mas_grande = np.max(np.linalg.svd(A)[1])
        error_teorico = 1 - (m_valor_singular_mas_chico / M_valor_singular_mas_grande) ** iteracion
        errores_teoricos.append(error_teorico)

        # Comprobación del umbral de error
        if error_practico < umbral_error:
            break

    return x, errores_practicos, errores_teoricos

# Ejemplo de uso
numero_condicion = 10
m = 100
n = 100
umbral_error = 1e-2

resultado = gradiente_descendente(numero_condicion, m, n, umbral_error)

print("Resultado:")
print("Valor de x:", resultado[0])
print("Error práctico:", resultado[1][-1])
print("Número de iteraciones:", len(resultado[1]))

# Graficar el error práctico y el error teórico
iteraciones = range(1, len(resultado[1]) + 1)

plt.plot(iteraciones, resultado[1], label='Error práctico')
plt.plot(iteraciones, resultado[2], label='Error teórico')
plt.xlabel('Iteración')
plt.ylabel('Error')
plt.legend()
plt.title('Error práctico vs. Error teórico')
plt.show()
